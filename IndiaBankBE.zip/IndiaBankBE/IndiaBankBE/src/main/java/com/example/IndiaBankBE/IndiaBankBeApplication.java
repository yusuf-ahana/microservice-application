package com.example.IndiaBankBE;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IndiaBankBeApplication {

	public static void main(String[] args) {
		SpringApplication.run(IndiaBankBeApplication.class, args);
	}

}
