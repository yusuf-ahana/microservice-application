package com.example.IndiaBankBE.Registration.Controller;

import com.example.IndiaBankBE.Registration.Model.UserDetails;
import com.example.IndiaBankBE.Registration.Service.UserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class UserDetailsController {

    @Autowired
    private UserDetailsService userDetailsService;

    @PostMapping("/registerUser")
    public UserDetails registerUser(@RequestBody UserDetails userDetails)
    {
        return userDetailsService.registerUser(userDetails);

    }

    @PutMapping("/updateRegisteredUser/{userId}")
    public UserDetails updateRegisteredUser(@PathVariable Long userId,@RequestBody UserDetails userDetails)
    {
        return userDetailsService.updateRegisteredUser(userId,userDetails);
    }
}
