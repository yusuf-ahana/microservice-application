package com.example.IndiaBankBE.Withdraw.Model;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name="withdraw")
public class Withdraw {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="withdraw_id")
   private Long withdrawId;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "amount", precision = 15, scale = 2)
    private BigDecimal amount;

    @Column(name = "type", length = 250)
    private String type;

    @Column(name = "date")
    @Temporal(TemporalType.DATE)
    private Date date;


    public Withdraw(){}
    public Withdraw(Long withdrawId, Long userId, BigDecimal amount, String type, Date date) {
        this.withdrawId = withdrawId;
        this.userId = userId;
        this.amount = amount;
        this.type = type;
        this.date = date;
    }

    public Long getWithdrawId() {
        return withdrawId;
    }

    public void setWithdrawId(Long withdrawId) {
        this.withdrawId = withdrawId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
