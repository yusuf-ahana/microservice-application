package com.example.IndiaBankBE.FixedDeposit.Controller;


import com.example.IndiaBankBE.FixedDeposit.Model.FixedDeposit;
import com.example.IndiaBankBE.FixedDeposit.Service.FixedDepositService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FixedDepositController {

    @Autowired
    private FixedDepositService fixedDepositService;

    @PostMapping("/fixedDepositMoney")
    public FixedDeposit fixedDepositMoney(@RequestBody FixedDeposit fixedDeposit)
    {
        return fixedDepositService.fixedDepositMoney(fixedDeposit);
    }

}
