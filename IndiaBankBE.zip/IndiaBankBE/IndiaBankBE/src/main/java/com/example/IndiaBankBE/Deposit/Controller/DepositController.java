package com.example.IndiaBankBE.Deposit.Controller;


import com.example.IndiaBankBE.Deposit.Model.Deposit;
import com.example.IndiaBankBE.Deposit.Service.DepositService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DepositController {

    @Autowired
    private DepositService depositService;

    @PostMapping("/depositMoney")
    public Deposit depositMoney(@RequestBody Deposit deposit)
    {
       return depositService.depositMoney(deposit);
    }
}
