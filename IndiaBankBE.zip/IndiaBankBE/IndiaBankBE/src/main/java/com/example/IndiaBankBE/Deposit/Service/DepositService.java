package com.example.IndiaBankBE.Deposit.Service;

import com.example.IndiaBankBE.Deposit.Model.Deposit;
import com.example.IndiaBankBE.Deposit.Repository.DepositRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DepositService {

    @Autowired
    private DepositRepository depositRepository;

    public Deposit depositMoney(Deposit deposit)
    {
        return depositRepository.save(deposit);
    }
}
