package com.example.IndiaBankBE.Withdraw.Repository;

import com.example.IndiaBankBE.Withdraw.Model.Withdraw;
import lombok.With;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WithdrawRepository extends JpaRepository<Withdraw,Long> {
}
