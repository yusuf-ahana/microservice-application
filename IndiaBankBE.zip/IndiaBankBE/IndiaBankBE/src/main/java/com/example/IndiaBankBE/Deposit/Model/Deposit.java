package com.example.IndiaBankBE.Deposit.Model;

import com.example.IndiaBankBE.Registration.Model.UserDetails;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "deposit")
public class Deposit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "deposit_id")
    private Long depositId;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "amount", precision = 15, scale = 2)
    private BigDecimal amount;

    @Column(name = "type", length = 250)
    private String type;

    @Column(name = "date")
    @Temporal(TemporalType.DATE)
    private Date date;

    // Constructors
    public Deposit() {}

    public Deposit(Long depositId, Long userId, BigDecimal amount, String type, Date date) {
        this.depositId = depositId;
        this.userId = userId;
        this.amount = amount;
        this.type = type;
        this.date = date;
    }

    public Long getDepositId() {
        return depositId;
    }

    public void setDepositId(Long depositId) {
        this.depositId = depositId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
