package com.example.IndiaBankBE.FixedDeposit.Repository;

import com.example.IndiaBankBE.FixedDeposit.Model.FixedDeposit;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FixedDepositRepository extends JpaRepository<FixedDeposit,Long> {
}
