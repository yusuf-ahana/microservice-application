package com.example.IndiaBankBE.Registration.Model;


import jakarta.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


@Entity
@Table(name = "user_details")
public class UserDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private Long userId;

    @Column(name = "user_name", length = 250)
    private String userName;

    @Column(name = "email_id", length = 250)
    private String emailId;

    @Column(name = "password", length = 250)
    private String password;

    @Column(name = "account_type", length = 250)
    private String accountType;

    @Column(name = "account_creation_date")

    private Date accountCreationDate;

    @Column(name = "balance", precision = 15, scale = 2)
    private BigDecimal balance;

    @Column(name = "address", length = 250)
    private String address;


//As  my db tables are created first so this mapping are not required
//    @OneToMany(mappedBy = "userDetails", cascade = CascadeType.ALL)
//    private List<Deposit> deposits;
//
//    @OneToMany(mappedBy = "userDetails", cascade = CascadeType.ALL)
//    private List<FixedDeposit> fixedDeposits;


    public UserDetails() {}

    public UserDetails(String userName, String emailId, String password, String accountType, Date accountCreationDate, BigDecimal balance, String address) {
        this.userName = userName;
        this.emailId = emailId;
        this.password = password;
        this.accountType = accountType;
        this.accountCreationDate = accountCreationDate;
        this.balance = balance;
        this.address = address;
    }

    // Getters and Setters for all fields, including lists
    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public Date getAccountCreationDate() {
        return accountCreationDate;
    }

    public void setAccountCreationDate(Date accountCreationDate) {
        this.accountCreationDate = accountCreationDate;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
