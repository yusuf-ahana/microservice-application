package com.example.IndiaBankBE.Login.Service;

import com.example.IndiaBankBE.Error.CustomException;
import com.example.IndiaBankBE.Login.Model.Login;
import com.example.IndiaBankBE.Registration.Model.UserDetails;
import com.example.IndiaBankBE.Registration.Repository.UserDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoginService {

    @Autowired
   private UserDetailsRepository userDetailsRepository;

    public String validateLoginCredentials(Login login)
    {
        boolean isValid= userDetailsRepository.existsByEmailIdAndPassword(login.getEmailId(),login.getPassword());

        if(isValid)
        {
           return "Login success";
        }
        else{
            throw new CustomException("Invalid email or password");
        }
    }
}
