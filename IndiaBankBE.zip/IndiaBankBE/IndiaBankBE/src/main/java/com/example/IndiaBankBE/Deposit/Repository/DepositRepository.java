package com.example.IndiaBankBE.Deposit.Repository;

import com.example.IndiaBankBE.Deposit.Model.Deposit;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DepositRepository extends JpaRepository<Deposit,Long> {
}
