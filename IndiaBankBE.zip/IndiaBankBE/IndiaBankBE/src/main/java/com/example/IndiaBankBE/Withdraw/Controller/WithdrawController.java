package com.example.IndiaBankBE.Withdraw.Controller;

import com.example.IndiaBankBE.Withdraw.Model.Withdraw;
import com.example.IndiaBankBE.Withdraw.Service.WithdrawService;
import lombok.With;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WithdrawController {

    @Autowired
    private WithdrawService withdrawService;

    public Withdraw withdrawMoney(@RequestBody Withdraw withdraw)
    {
        return withdrawService.withdrawMoney(withdraw);
    }


}
