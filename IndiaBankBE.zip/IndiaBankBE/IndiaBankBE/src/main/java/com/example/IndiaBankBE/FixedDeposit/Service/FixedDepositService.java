package com.example.IndiaBankBE.FixedDeposit.Service;

import com.example.IndiaBankBE.FixedDeposit.Model.FixedDeposit;
import com.example.IndiaBankBE.FixedDeposit.Repository.FixedDepositRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FixedDepositService {

    @Autowired
    private FixedDepositRepository fixedDepositRepository;

    public FixedDeposit fixedDepositMoney(FixedDeposit fixedDeposit)
    {
        return fixedDepositRepository.save(fixedDeposit);
    }
}
