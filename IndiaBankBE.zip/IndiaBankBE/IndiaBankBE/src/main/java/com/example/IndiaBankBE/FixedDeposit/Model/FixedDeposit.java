package com.example.IndiaBankBE.FixedDeposit.Model;

import com.example.IndiaBankBE.Registration.Model.UserDetails;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "fixed_deposit")
public class FixedDeposit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "fixed_deposit_id")
    private Long fixedDepositId;

    @Column(name = "user_id", nullable = false)
    private Long userId;

    @Column(name = "amount", precision = 15, scale = 2)
    private BigDecimal amount;

    @Column(name = "deposit_date")
    @Temporal(TemporalType.DATE)
    private Date depositDate;

    @Column(name = "deposit_tenure")
    @Temporal(TemporalType.DATE)
    private Date depositTenure;

    // Constructors
    public FixedDeposit() {}

    public FixedDeposit(Long fixedDepositId, Long userId, BigDecimal amount, Date depositDate, Date depositTenure) {
        this.fixedDepositId = fixedDepositId;
        this.userId = userId;
        this.amount = amount;
        this.depositDate = depositDate;
        this.depositTenure = depositTenure;
    }

    public Long getFixedDepositId() {
        return fixedDepositId;
    }

    public void setFixedDepositId(Long fixedDepositId) {
        this.fixedDepositId = fixedDepositId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public Date getDepositDate() {
        return depositDate;
    }

    public void setDepositDate(Date depositDate) {
        this.depositDate = depositDate;
    }

    public Date getDepositTenure() {
        return depositTenure;
    }

    public void setDepositTenure(Date depositTenure) {
        this.depositTenure = depositTenure;
    }
}
