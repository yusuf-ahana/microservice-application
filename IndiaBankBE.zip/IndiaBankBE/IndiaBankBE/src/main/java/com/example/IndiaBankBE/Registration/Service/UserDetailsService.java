package com.example.IndiaBankBE.Registration.Service;


import com.example.IndiaBankBE.Error.CustomException;
import com.example.IndiaBankBE.Registration.Model.UserDetails;
import com.example.IndiaBankBE.Registration.Repository.UserDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserDetailsService {

    @Autowired
    private UserDetailsRepository userDetailsRepository;

    public UserDetails registerUser(UserDetails userDetails) {
        return userDetailsRepository.save(userDetails);
    }

    public  UserDetails updateRegisteredUser(Long userId,UserDetails userDetails ) {
       UserDetails existingUser= userDetailsRepository.findById(userId)
          .orElseThrow(() -> new CustomException("User with ID " + userId + " not found."));
        existingUser.setUserName(userDetails.getUserName());
        existingUser.setEmailId(userDetails.getEmailId());
        existingUser.setPassword(userDetails.getPassword());
        existingUser.setAccountType(userDetails.getAccountType());
        existingUser.setAccountCreationDate(userDetails.getAccountCreationDate());
        existingUser.setBalance(userDetails.getBalance());
        existingUser.setAddress(userDetails.getAddress());

        return userDetailsRepository.save(existingUser);
    }

}
