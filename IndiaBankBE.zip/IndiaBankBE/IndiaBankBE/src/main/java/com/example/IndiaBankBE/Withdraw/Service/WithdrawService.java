package com.example.IndiaBankBE.Withdraw.Service;

import com.example.IndiaBankBE.Withdraw.Model.Withdraw;
import com.example.IndiaBankBE.Withdraw.Repository.WithdrawRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class WithdrawService {

    @Autowired
    private WithdrawRepository withdrawRepository;

    public Withdraw withdrawMoney(Withdraw withdraw)
    {
        return withdrawRepository.save(withdraw);
    }


}
