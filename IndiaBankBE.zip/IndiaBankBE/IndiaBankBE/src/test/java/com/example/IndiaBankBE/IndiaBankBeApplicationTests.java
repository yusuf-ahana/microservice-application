package com.example.IndiaBankBE;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IndiaBankBeApplicationTests {

	@Test
	void contextLoads() {
	}

}
